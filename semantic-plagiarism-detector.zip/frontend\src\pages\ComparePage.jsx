import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { comparisonsAPI } from '../services/api';
import { FileText, Upload, X, AlertCircle, Loader2 } from 'lucide-react';

const ComparePage = () => {
  const [referenceText, setReferenceText] = useState('');
  const [submittedText, setSubmittedText] = useState('');
  const [referenceFilename, setReferenceFilename] = useState('reference.txt');
  const [submittedFilename, setSubmittedFilename] = useState('submitted.txt');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!referenceText.trim() || !submittedText.trim()) {
      setError('Both reference and submitted text are required');
      return;
    }

    setLoading(true);

    try {
      const response = await comparisonsAPI.create({
        reference_text: referenceText,
        submitted_text: submittedText,
        reference_filename: referenceFilename,
        submitted_filename: submittedFilename,
      });

      navigate(`/results/${response.data.id}`);
    } catch (err) {
      setError(err.response?.data?.detail || 'Comparison failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const clearAll = () => {
    setReferenceText('');
    setSubmittedText('');
    setError('');
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Compare Documents</h1>
        <p className="text-gray-600">
          Paste text from reference and submitted documents to detect semantic similarity
        </p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-start">
          <AlertCircle className="h-5 w-5 text-red-600 mt-0.5 mr-3 flex-shrink-0" />
          <p className="text-sm text-red-800">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid md:grid-cols-2 gap-6">
          {/* Reference Document */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <FileText className="h-5 w-5 text-primary-600 mr-2" />
                <h2 className="text-lg font-semibold text-gray-900">Reference Document</h2>
              </div>
              <button
                type="button"
                onClick={() => setReferenceText('')}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Filename (optional)
              </label>
              <input
                type="text"
                value={referenceFilename}
                onChange={(e) => setReferenceFilename(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
                placeholder="reference.txt"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Reference Text
              </label>
              <textarea
                value={referenceText}
                onChange={(e) => setReferenceText(e.target.value)}
                rows={12}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 resize-none"
                placeholder="Paste the reference text here..."
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                {referenceText.split(/\s+/).filter(word => word).length} words
              </p>
            </div>
          </div>

          {/* Submitted Document */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <FileText className="h-5 w-5 text-primary-600 mr-2" />
                <h2 className="text-lg font-semibold text-gray-900">Submitted Document</h2>
              </div>
              <button
                type="button"
                onClick={() => setSubmittedText('')}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Filename (optional)
              </label>
              <input
                type="text"
                value={submittedFilename}
                onChange={(e) => setSubmittedFilename(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
                placeholder="submitted.txt"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Submitted Text
              </label>
              <textarea
                value={submittedText}
                onChange={(e) => setSubmittedText(e.target.value)}
                rows={12}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 resize-none"
                placeholder="Paste the submitted text here..."
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                {submittedText.split(/\s+/).filter(word => word).length} words
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-between items-center">
          <button
            type="button"
            onClick={clearAll}
            className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
          >
            Clear All
          </button>

          <button
            type="submit"
            disabled={loading}
            className="px-8 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
          >
            {loading ? (
              <>
                <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Upload className="h-5 w-5 mr-2" />
                Check Plagiarism
              </>
            )}
          </button>
        </div>
      </form>

      {/* Info Box */}
      <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start">
          <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5 mr-3 flex-shrink-0" />
          <div className="text-sm text-blue-800">
            <p className="font-semibold mb-1">How it works</p>
            <p>
              The system uses semantic analysis to detect meaning-based similarities, not just word-for-word matches. 
              It can identify paraphrasing, conceptual similarities, and direct copying. Results include detailed 
              explanations for each flagged section.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComparePage;
