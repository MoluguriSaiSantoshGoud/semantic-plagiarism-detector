from typing import List, Optional
import numpy as np
from sentence_transformers import SentenceTransformer
from app.config import settings


class EmbeddingService:
    """Service for generating semantic embeddings using Sentence Transformers."""
    
    _instance = None
    _model = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._model is None:
            self._load_model()
    
    def _load_model(self):
        """Load the embedding model (only once)."""
        try:
            print(f"Loading embedding model: {settings.embedding_model}")
            self._model = SentenceTransformer(settings.embedding_model)
            print("Model loaded successfully")
        except Exception as e:
            raise Exception(f"Failed to load embedding model: {str(e)}")
    
    def generate_embedding(self, text: str) -> np.ndarray:
        """Generate embedding for a single text."""
        if not text or not text.strip():
            return np.zeros(384)  # Default dimension for all-MiniLM-L6-v2
        
        embedding = self._model.encode(text, convert_to_numpy=True)
        return self._normalize_embedding(embedding)
    
    def generate_embeddings(self, texts: List[str]) -> np.ndarray:
        """Generate embeddings for multiple texts in batch."""
        if not texts:
            return np.array([])
        
        # Filter empty texts
        valid_texts = [t if t and t.strip() else " " for t in texts]
        
        embeddings = self._model.encode(valid_texts, convert_to_numpy=True, batch_size=32)
        
        # Normalize each embedding
        normalized_embeddings = np.array([self._normalize_embedding(emb) for emb in embeddings])
        
        return normalized_embeddings
    
    def _normalize_embedding(self, embedding: np.ndarray) -> np.ndarray:
        """Normalize embedding to unit length."""
        norm = np.linalg.norm(embedding)
        if norm == 0:
            return embedding
        return embedding / norm
    
    def calculate_semantic_similarity(self, text_a: str, text_b: str) -> float:
        """Calculate cosine similarity between two texts."""
        embedding_a = self.generate_embedding(text_a)
        embedding_b = self.generate_embedding(text_b)
        
        return float(np.dot(embedding_a, embedding_b))
    
    def calculate_similarity_matrix(self, chunks_a: List[str], chunks_b: List[str]) -> np.ndarray:
        """Calculate similarity matrix between two sets of chunks."""
        embeddings_a = self.generate_embeddings(chunks_a)
        embeddings_b = self.generate_embeddings(chunks_b)
        
        if len(embeddings_a) == 0 or len(embeddings_b) == 0:
            return np.array([])
        
        # Cosine similarity matrix
        similarity_matrix = np.dot(embeddings_a, embeddings_b.T)
        
        return similarity_matrix
